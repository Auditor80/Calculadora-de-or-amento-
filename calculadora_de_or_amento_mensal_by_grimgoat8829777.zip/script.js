import confetti from 'canvas-confetti';

const incomeForm = document.getElementById('income-form');
const expenseForm = document.getElementById('expense-form');
const incomeList = document.getElementById('income-list');
const expenseList = document.getElementById('expense-list');
const totalIncomeEl = document.getElementById('total-income');
const totalExpensesEl = document.getElementById('total-expenses');
const balanceEl = document.getElementById('balance');

let incomes = JSON.parse(localStorage.getItem('incomes')) || [];
let expenses = JSON.parse(localStorage.getItem('expenses')) || [];
let nextId = 0;

function getNextId() {
    const allItems = [...incomes, ...expenses];
    if (allItems.length === 0) return 1;
    return Math.max(...allItems.map(item => item.id)) + 1;
}

function saveData() {
    localStorage.setItem('incomes', JSON.stringify(incomes));
    localStorage.setItem('expenses', JSON.stringify(expenses));
}

function formatCurrency(amount) {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(amount);
}

function addItem(type, description, amount) {
    const item = {
        id: nextId++,
        description,
        amount: parseFloat(amount)
    };
    if (type === 'income') {
        incomes.push(item);
        if(amount > 500) {
           confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
        }
    } else {
        expenses.push(item);
    }
    updateUI();
}

function deleteItem(type, id) {
    if (type === 'income') {
        incomes = incomes.filter(item => item.id !== id);
    } else {
        expenses = expenses.filter(item => item.id !== id);
    }
    updateUI();
}

function createListItem(item, type) {
    const li = document.createElement('li');
    li.dataset.id = item.id;
    li.innerHTML = `
        <span class="item-description">${item.description}</span>
        <div>
            <span class="item-amount">${formatCurrency(item.amount)}</span>
            <button class="delete-btn" data-type="${type}" data-id="${item.id}">&times;</button>
        </div>
    `;
    return li;
}

function updateUI() {
    // Render lists
    incomeList.innerHTML = '';
    incomes.forEach(item => incomeList.appendChild(createListItem(item, 'income')));

    expenseList.innerHTML = '';
    expenses.forEach(item => expenseList.appendChild(createListItem(item, 'expense')));

    // Update summary
    const totalIncome = incomes.reduce((sum, item) => sum + item.amount, 0);
    const totalExpenses = expenses.reduce((sum, item) => sum + item.amount, 0);
    const balance = totalIncome - totalExpenses;

    totalIncomeEl.textContent = formatCurrency(totalIncome);
    totalExpensesEl.textContent = formatCurrency(totalExpenses);
    balanceEl.textContent = formatCurrency(balance);

    balanceEl.classList.remove('positive', 'negative');
    if (balance >= 0) {
        balanceEl.classList.add('positive');
    } else {
        balanceEl.classList.add('negative');
    }
    
    saveData();
}

incomeForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const description = document.getElementById('income-description').value;
    const amount = document.getElementById('income-amount').value;
    if (description && amount) {
        addItem('income', description, amount);
        incomeForm.reset();
    }
});

expenseForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const description = document.getElementById('expense-description').value;
    const amount = document.getElementById('expense-amount').value;
    if (description && amount) {
        addItem('expense', description, amount);
        expenseForm.reset();
    }
});

function handleListClick(e) {
    if (e.target.classList.contains('delete-btn')) {
        const type = e.target.dataset.type;
        const id = parseInt(e.target.dataset.id);
        deleteItem(type, id);
    }
}

incomeList.addEventListener('click', handleListClick);
expenseList.addEventListener('click', handleListClick);

// Initial Load
document.addEventListener('DOMContentLoaded', () => {
    nextId = getNextId();
    updateUI();
});

